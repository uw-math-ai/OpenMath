# Summary of changes for run 37d9e153-27ac-4265-a6b3-cb96ea6b6141
Filled in the `sorry` in `tendsto_h_squared_zero.lean`. The proof uses `Continuous.tendsto'` with `continuous_pow 2` (which says `x ^ 2` is continuous) and `norm_num` to discharge the `0 ^ 2 = 0` side goal:

```lean
exact Continuous.tendsto' (continuous_pow 2) _ _ (by norm_num)
```

The file builds successfully with no remaining sorries.