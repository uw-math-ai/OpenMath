# Summary of changes for run 7e508e7b-2c30-4c77-8e4d-63ef7e79fa2f
Filled in the sorry in `tendsto_finset_sum_abs_zero.lean`. The proof is:

```lean
simpa using tendsto_finset_sum _ fun i hi => Filter.Tendsto.abs (hf i hi)
```

This applies `Filter.Tendsto.abs` to each component hypothesis `hf i hi` (getting that `|f h i| → |0| = 0`), then lifts to the finite sum via `tendsto_finset_sum`. The `simpa` closes the goal by simplifying `∑ i ∈ s, 0 = 0`.