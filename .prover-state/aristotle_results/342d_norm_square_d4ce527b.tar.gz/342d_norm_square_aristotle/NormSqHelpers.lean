/-
Helper lemmas for the norm-square theorem.
-/
import Mathlib.RingTheory.Polynomial.ShiftedLegendre
import Mathlib.Algebra.Polynomial.AlgebraMap
import Mathlib.Algebra.Polynomial.Degree.Lemmas
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Analysis.SpecialFunctions.Gamma.Beta

open Polynomial MeasureTheory intervalIntegral Finset

namespace NormSqHelpers

/-
============================================================
Boundary vanishing lemmas
============================================================

The k-th iterated derivative of X^n * (1-X)^n vanishes at x=0 for k < n.
-/
lemma deriv_iter_XnOneMinusXn_eval_zero (n : ℕ) (k : ℕ) (hk : k < n) :
    (Polynomial.derivative^[k]
      ((X : Polynomial ℝ) ^ n * (1 - X) ^ n)).eval 0 = 0 := by
        rw [ Polynomial.iterate_derivative_mul ];
        rw [ Polynomial.eval_finset_sum, Finset.sum_eq_zero ] ; intros ; simp +decide [ Polynomial.eval_pow, Polynomial.eval_X, Polynomial.eval_one, Polynomial.eval_sub, Polynomial.eval_mul, Polynomial.eval_add, Polynomial.eval_natCast, Polynomial.eval_ofNat, Polynomial.iterate_derivative_X_pow_eq_smul, Nat.descFactorial_eq_zero_iff_lt.mpr ( Nat.sub_lt ( pos_of_gt hk ) ( Nat.succ_pos _ ) ) ];
        exact Or.inr <| Or.inr <| Or.inl <| Nat.sub_ne_zero_of_lt <| by omega;

/-
The k-th iterated derivative of X^n * (1-X)^n vanishes at x=1 for k < n.
-/
lemma deriv_iter_XnOneMinusXn_eval_one (n : ℕ) (k : ℕ) (hk : k < n) :
    (Polynomial.derivative^[k]
      ((X : Polynomial ℝ) ^ n * (1 - X) ^ n)).eval 1 = 0 := by
        -- By symmetry, we can consider the expression $(1-X)^n X^n$ and apply the same argument.
        have h_symm : ((Polynomial.derivative^[k] ((Polynomial.X : Polynomial ℝ) ^ n * (1 - Polynomial.X) ^ n)).eval 1) = ((Polynomial.derivative^[k] ((1 - Polynomial.X) ^ n * Polynomial.X ^ n)).eval 1) := by
          rw [ mul_comm ];
        -- By substituting $X$ with $1 - X$, the polynomial becomes $(1 - X)^n (1 - (1 - X))^n = (1 - X)^n X^n$, which is symmetric.
        have h_symm : ((Polynomial.derivative^[k] ((1 - Polynomial.X) ^ n * Polynomial.X ^ n)).eval 1) = ((Polynomial.derivative^[k] ((Polynomial.X : Polynomial ℝ) ^ n * (1 - Polynomial.X) ^ n)).eval 0) * (-1) ^ k := by
          have h_symm : ∀ (p : Polynomial ℝ), ((Polynomial.derivative^[k] (p.comp (1 - Polynomial.X))).eval 1) = ((Polynomial.derivative^[k] p).eval 0) * (-1) ^ k := by
            simp_all +decide [ mul_comm ];
          convert h_symm ( Polynomial.X ^ n * ( 1 - Polynomial.X ) ^ n ) using 1 ; norm_num [ mul_comm ];
        have := deriv_iter_XnOneMinusXn_eval_zero n k hk; aesop;

-- ============================================================
-- IBP for polynomials
-- ============================================================

/-- Integration by parts for polynomials when q vanishes at both endpoints. -/
lemma poly_ibp_vanishing (p q : Polynomial ℝ) (hq0 : q.eval 0 = 0) (hq1 : q.eval 1 = 0) :
    ∫ x in (0:ℝ)..1, p.eval x * (Polynomial.derivative q).eval x =
      -(∫ x in (0:ℝ)..1, (Polynomial.derivative p).eval x * q.eval x) := by
  have hu : ∀ x ∈ Set.uIcc (0:ℝ) 1, HasDerivAt (fun x => p.eval x)
    ((Polynomial.derivative p).eval x) x := fun x _ => p.hasDerivAt x
  have hv : ∀ x ∈ Set.uIcc (0:ℝ) 1, HasDerivAt (fun x => q.eval x)
    ((Polynomial.derivative q).eval x) x := fun x _ => q.hasDerivAt x
  have hu' : IntervalIntegrable (fun x => (Polynomial.derivative p).eval x) volume 0 1 :=
    (p.derivative.differentiable.continuous).continuousOn.intervalIntegrable
  have hv' : IntervalIntegrable (fun x => (Polynomial.derivative q).eval x) volume 0 1 :=
    (q.derivative.differentiable.continuous).continuousOn.intervalIntegrable
  have := integral_mul_deriv_eq_deriv_mul hu hv hu' hv'
  simp [hq0, hq1] at this
  linarith

-- ============================================================
-- Iterated IBP
-- ============================================================

private lemma gen_ibp (n m : ℕ) (hm : m ≤ n) :
    ∀ p : Polynomial ℝ,
    ∫ x in (0:ℝ)..1, p.eval x *
      (Polynomial.derivative^[m] ((X : Polynomial ℝ) ^ n * (1 - X) ^ n)).eval x =
    (-1 : ℝ) ^ m * ∫ x in (0:ℝ)..1,
      (Polynomial.derivative^[m] p).eval x *
      ((X : Polynomial ℝ) ^ n * (1 - X) ^ n).eval x := by
  induction m with
  | zero => intro p; simp
  | succ m ih =>
    intro p
    rw [Function.iterate_succ_apply']
    have hm' : m < n := Nat.lt_of_succ_le hm
    rw [poly_ibp_vanishing p _ (deriv_iter_XnOneMinusXn_eval_zero n m hm')
      (deriv_iter_XnOneMinusXn_eval_one n m hm')]
    rw [ih (Nat.le_of_lt hm') (Polynomial.derivative p)]
    have hcomm : Polynomial.derivative^[m] (Polynomial.derivative p) =
      Polynomial.derivative (Polynomial.derivative^[m] p) :=
      Function.Commute.iterate_self Polynomial.derivative m p
    rw [show (m + 1 : ℕ) = m + 1 from rfl, Function.iterate_succ_apply', hcomm]
    ring

lemma iterated_ibp (p : Polynomial ℝ) (n : ℕ) :
    ∫ x in (0:ℝ)..1, p.eval x *
      (Polynomial.derivative^[n] ((X : Polynomial ℝ) ^ n * (1 - X) ^ n)).eval x =
    (-1 : ℝ) ^ n * ∫ x in (0:ℝ)..1,
      (Polynomial.derivative^[n] p).eval x *
      ((X : Polynomial ℝ) ^ n * (1 - X) ^ n).eval x :=
  gen_ibp n n le_rfl p

-- ============================================================
-- n-th derivative of degree-n polynomial
-- ============================================================

lemma iterate_derivative_degree_eq (p : Polynomial ℝ) (n : ℕ) (hn : p.natDegree = n) :
    Polynomial.derivative^[n] p = C (p.leadingCoeff * n.factorial) := by
  have h_ind : ∀ k ≤ n, (derivative^[k] p).coeff (n - k) =
    p.leadingCoeff * Nat.descFactorial n k := by
    intro k hk
    rw [Polynomial.coeff_iterate_derivative]
    simp +decide [hn, Polynomial.leadingCoeff]
    ring
    rw [Nat.sub_add_cancel hk, mul_comm]
  convert Polynomial.eq_C_of_natDegree_eq_zero _
  · simpa [Nat.descFactorial_self] using Eq.symm (h_ind n le_rfl)
  · rw [Polynomial.natDegree_eq_zero_iff_degree_le_zero, Polynomial.degree_le_zero_iff]
    ext (_ | k) <;> simp_all +decide [Polynomial.coeff_iterate_derivative]
    rw [Polynomial.coeff_eq_zero_of_natDegree_lt (by linarith)]

/-
============================================================
Beta integral
============================================================
-/
lemma integral_pow_mul_one_sub_pow (n : ℕ) :
    ∫ x in (0:ℝ)..1, x ^ n * (1 - x) ^ n =
      ((n.factorial : ℝ) ^ 2 / ((2 * n + 1).factorial : ℝ)) := by
        have h_beta : Complex.betaIntegral (n + 1 : ℂ) (n + 1 : ℂ) = (Nat.factorial n : ℂ) * (Nat.factorial n : ℂ) / (Nat.factorial (2 * n + 1) : ℂ) := by
          have h_beta : Complex.betaIntegral (n + 1 : ℂ) (n + 1 : ℂ) = (Nat.factorial n : ℂ) / (∏ j ∈ Finset.range (n + 1), (n + 1 + j : ℂ)) := by
            convert Complex.betaIntegral_eval_nat_add_one_right _ _ using 1;
            norm_cast ; norm_num;
          -- The product $\prod_{j=0}^{n} (n+1+j)$ can be rewritten as $\frac{(2n+1)!}{n!}$.
          have h_prod : ∏ j ∈ Finset.range (n + 1), (n + 1 + j : ℂ) = (Nat.factorial (2 * n + 1) : ℂ) / (Nat.factorial n : ℂ) := by
            have h_prod : ∏ j ∈ Finset.range (n + 1), (n + 1 + j : ℂ) = (∏ j ∈ Finset.range (2 * n + 1), (j + 1 : ℂ)) / (∏ j ∈ Finset.range n, (j + 1 : ℂ)) := by
              rw [ eq_div_iff <| Finset.prod_ne_zero_iff.mpr fun _ _ => Nat.cast_add_one_ne_zero _ ];
              rw [ two_mul, add_assoc, Finset.prod_range_add ];
              rw [ Finset.prod_range_add ] ; norm_num [ add_comm, add_left_comm, add_assoc ];
              rw [ Finset.prod_range_succ ] ; ring;
            exact h_prod.trans ( mod_cast by simp +decide [ Nat.factorial ] );
          rw [ h_beta, h_prod, div_div_eq_mul_div ];
        convert congr_arg Complex.re h_beta using 1;
        · convert intervalIntegral.integral_ofReal.symm using 1;
          rotate_left;
          exact?;
          exact 0;
          exact?;
          exact fun x => x ^ n * ( 1 - x ) ^ n;
          norm_num [ Complex.ext_iff, Complex.betaIntegral ];
          norm_cast;
          erw [ intervalIntegral.integral_ofReal, intervalIntegral.integral_ofReal ] ; norm_num;
        · norm_cast ; norm_num [ sq ]

-- ============================================================
-- Arithmetic identity
-- ============================================================

lemma choose_mul_factorial_sq_div (n : ℕ) :
    (Nat.choose (2 * n) n : ℝ) * ((n.factorial : ℝ) ^ 2 / ((2 * n + 1).factorial : ℝ)) =
      1 / (2 * n + 1) := by
  field_simp [Nat.factorial_succ]
  rw_mod_cast [Nat.choose_eq_factorial_div_factorial] <;> norm_num [two_mul, Nat.succ_eq_add_one]
  nlinarith! [Nat.div_mul_cancel (show n.factorial * n.factorial ∣ (n + n).factorial
    from Nat.factorial_mul_factorial_dvd_factorial_add _ _), Nat.factorial_succ (n + n)]

end NormSqHelpers