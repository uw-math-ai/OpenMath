/-
# Aristotle submission: Butcher §342 (342d) norm-square integral of shifted Legendre polynomials on [0,1]

## Target

Prove `∫_0^1 P_n^*(x)^2 dx = 1 / (2n + 1)`, where `P_n^*` is Butcher's
shifted Legendre polynomial on `[0, 1]` (signed so that `P_n^*(1) = 1`).

## Strategy

Apply the Rodrigues formula to rewrite one factor of `(P_n^*)^2`, then use iterated
integration by parts `n` times (boundary terms vanish), reduce to the Beta integral
`∫₀¹ x^n (1-x)^n dx = (n!)²/(2n+1)!`, and simplify.
-/

import NormSqHelpers

namespace OpenMath.Chapter3.Section342Aristotle

open Polynomial MeasureTheory intervalIntegral Finset

/-- **Butcher's shifted Legendre polynomial** `P_n^*` on `[0,1]`. -/
noncomputable def butcherShiftedLegendre (n : ℕ) : Polynomial ℝ :=
  Polynomial.C ((-1 : ℝ) ^ n) *
    (Polynomial.shiftedLegendre n).map (Int.castRingHom ℝ)

/-- (342b) — provided as a hypothesis for Aristotle. -/
axiom butcherShiftedLegendre_eval_one (n : ℕ) :
    (butcherShiftedLegendre n).eval 1 = 1

/-- (342c) — provided as a hypothesis for Aristotle. -/
axiom butcherShiftedLegendre_eval_one_sub (n : ℕ) (x : ℝ) :
    (butcherShiftedLegendre n).eval (1 - x) =
      (-1 : ℝ) ^ n * (butcherShiftedLegendre n).eval x

/-- (342e) — Rodrigues' formula. -/
axiom butcherShiftedLegendre_rodrigues (n : ℕ) :
    Polynomial.C ((n.factorial : ℝ)) * butcherShiftedLegendre n
      = Polynomial.C ((-1 : ℝ) ^ n) *
        Polynomial.derivative^[n]
          ((Polynomial.X : Polynomial ℝ) ^ n *
            (1 - (Polynomial.X : Polynomial ℝ)) ^ n)

/-- (degree) -/
axiom butcherShiftedLegendre_natDegree (n : ℕ) :
    (butcherShiftedLegendre n).natDegree = n

/-- `P_n^*(0) = (-1)^n` -/
axiom butcherShiftedLegendre_eval_zero (n : ℕ) :
    (butcherShiftedLegendre n).eval 0 = (-1 : ℝ) ^ n

/-- `P_0^* = C 1` -/
axiom butcherShiftedLegendre_zero :
    butcherShiftedLegendre 0 = Polynomial.C 1

/-- `P_1^* = C 2 * X - C 1` -/
axiom butcherShiftedLegendre_one :
    butcherShiftedLegendre 1 =
      Polynomial.C 2 * Polynomial.X - Polynomial.C 1

-- ============================================================
-- Leading coefficient
-- ============================================================

private lemma butcherShiftedLegendre_leadingCoeff (n : ℕ) :
    (butcherShiftedLegendre n).leadingCoeff = (Nat.choose (2 * n) n : ℝ) := by
  unfold butcherShiftedLegendre
  simp_all +decide [Polynomial.leadingCoeff_mul]
  rw [Polynomial.leadingCoeff_map_of_leadingCoeff_ne_zero] <;>
    norm_num [Polynomial.leadingCoeff, Polynomial.natDegree]
  · erw [Polynomial.coeff_shiftedLegendre]; norm_num
    erw [WithBot.unbotD_coe]; ring_nf; norm_num
    ring; norm_num [← mul_pow]
  · erw [Polynomial.coeff_shiftedLegendre]; norm_num
    exact ⟨Nat.ne_of_gt <| Nat.choose_pos <| Nat.le_refl _,
      Nat.ne_of_gt <| Nat.choose_pos <| Nat.le_add_left _ _⟩

-- ============================================================
-- Intermediate lemmas for the main proof
-- ============================================================

private lemma bsl_eval_rodrigues (n : ℕ) (x : ℝ) :
    (n.factorial : ℝ) * (butcherShiftedLegendre n).eval x = (-1 : ℝ) ^ n *
      (Polynomial.derivative^[n] ((X : Polynomial ℝ) ^ n * (1 - X) ^ n)).eval x := by
  have h := congr_arg (Polynomial.eval x) (butcherShiftedLegendre_rodrigues n)
  simp [Polynomial.eval_mul] at h; exact h

private lemma nth_deriv_bsl_eval (n : ℕ) (x : ℝ) :
    (Polynomial.derivative^[n] (butcherShiftedLegendre n)).eval x =
      (Nat.choose (2 * n) n : ℝ) * (n.factorial : ℝ) := by
  rw [NormSqHelpers.iterate_derivative_degree_eq (butcherShiftedLegendre n) n
    (butcherShiftedLegendre_natDegree n)]
  simp [butcherShiftedLegendre_leadingCoeff]

private lemma XnOneMinusXn_eval (n : ℕ) (x : ℝ) :
    ((X : Polynomial ℝ) ^ n * (1 - X) ^ n).eval x = x ^ n * (1 - x) ^ n := by
  simp [eval_mul, eval_pow, eval_sub, eval_X, eval_one]

-- ============================================================
-- Main theorem
-- ============================================================

/-- **Butcher §342 (342d)** — norm-square integral on `[0, 1]`.

For all `n`, `∫_0^1 (P_n^*(x))^2 dx = 1 / (2n + 1)`. -/
theorem butcherShiftedLegendre_norm_sq (n : ℕ) :
    ∫ x in (0 : ℝ)..1, (butcherShiftedLegendre n).eval x ^ 2 =
      1 / (2 * n + 1) := by
  have hfact_pos : (0 : ℝ) < n.factorial := Nat.cast_pos.mpr (Nat.factorial_pos n)
  have hfact_ne : (n.factorial : ℝ) ≠ 0 := ne_of_gt hfact_pos
  -- Step 1: Rewrite sq as mul_self
  simp_rw [sq]
  -- Step 2: Use Rodrigues to replace one factor of P_n^*
  have h_integrand :
    (fun x => (butcherShiftedLegendre n).eval x * (butcherShiftedLegendre n).eval x) =
    (fun x => (-1:ℝ)^n / (n.factorial : ℝ) *
      ((butcherShiftedLegendre n).eval x *
        (Polynomial.derivative^[n] ((X : Polynomial ℝ) ^ n * (1 - X) ^ n)).eval x)) := by
    ext x
    have hrod := bsl_eval_rodrigues n x
    have : (butcherShiftedLegendre n).eval x = (-1:ℝ)^n / n.factorial *
        (Polynomial.derivative^[n] ((X : Polynomial ℝ) ^ n * (1 - X) ^ n)).eval x := by
      field_simp; linarith
    rw [this]; ring
  rw [show (fun x => (butcherShiftedLegendre n).eval x *
    (butcherShiftedLegendre n).eval x) = _ from h_integrand]
  rw [intervalIntegral.integral_const_mul]
  -- Step 3: Apply iterated IBP (transfers n derivatives from f_n to P_n^*)
  rw [NormSqHelpers.iterated_ibp (butcherShiftedLegendre n) n]
  -- Step 4: Substitute the constant value of D^n(P_n^*) and simplify X^n(1-X)^n
  simp_rw [nth_deriv_bsl_eval, XnOneMinusXn_eval]
  -- Step 5: Pull constant out of integral
  rw [show (fun x : ℝ => (Nat.choose (2 * n) n : ℝ) * (n.factorial : ℝ) *
    (x ^ n * (1 - x) ^ n)) =
    (fun x : ℝ => ((Nat.choose (2 * n) n : ℝ) * (n.factorial : ℝ)) *
    (x ^ n * (1 - x) ^ n)) from by ext; ring]
  rw [intervalIntegral.integral_const_mul]
  -- Step 6: Substitute the Beta integral ∫₀¹ x^n(1-x)^n dx = (n!)²/(2n+1)!
  rw [NormSqHelpers.integral_pow_mul_one_sub_pow]
  -- Step 7: Simplify (-1)^n * (-1)^n = 1 and cancel n!
  rw [show (-1:ℝ)^n / (n.factorial : ℝ) * ((-1:ℝ)^n *
    ((Nat.choose (2*n) n : ℝ) * (n.factorial : ℝ) *
    ((n.factorial : ℝ) ^ 2 / ((2 * n + 1).factorial : ℝ)))) =
    (Nat.choose (2*n) n : ℝ) * ((n.factorial : ℝ)^2 / ((2*n+1).factorial : ℝ)) from by
      have : (-1:ℝ)^n * (-1:ℝ)^n = 1 := by
        rw [← pow_add]; simp [Even.neg_one_pow ⟨n, rfl⟩]
      field_simp
      nlinarith [this]]
  -- Step 8: Apply the arithmetic identity C(2n,n) * (n!)²/(2n+1)! = 1/(2n+1)
  exact NormSqHelpers.choose_mul_factorial_sq_div n

end OpenMath.Chapter3.Section342Aristotle
